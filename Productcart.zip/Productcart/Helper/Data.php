<?php

  namespace Ey\Productcart\Helper;

  use Magento\Framework\App\Helper\AbstractHelper;
  use Magento\Framework\App\Helper\Context;
  use Magento\Framework\Data\Form\FormKey;

class Data extends AbstractHelper
{

    protected $formKey;


    public function __construct(
        Context $context,
        FormKey $formKey
    ) {
        $this->formKey = $formKey;
        parent::__construct($context);

    }//end __construct()


    public function getFormKey()
    {
        return 'hello';
        // $this->formKey->getFormKey();

    }//end getFormKey()


    public function testval()
    {
        return 'hello';

    }//end testval()


    public function addCart()
    {
        $writer = new \Zend_Log_Writer_Stream(BP.'/var/log/helper.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('Hiii');

        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $formKey       = $objectManager->get('Magento\Framework\Data\Form\FormKey');

            $product = $objectManager->get('Magento\Catalog\Model\Product');

            $cart = $objectManager->get('Magento\Checkout\Model\Cart');

            $productId = 117;
            // Your Product Id
            $logger->info('Hiii111');
            $params = [
                'form_key' => $formKey->getFormKey(),
                'product'  => $productId,
                'qty'      => 1,
            // quantity of product
            ];
            echo '<pre>';
            print_r($params);
            // Load the product based on productID
            $_product = $product->load($productId);
            echo $_product->getName();
            $logger->info('Hiii2222');
            $cart->addProduct($_product, $params);
            $logger->info('Hiii3333');
            $cart->save();
            $logger->info('Hiii444');
        } catch (\Exception $e) {
            $logger->info($e->getMessage());
        }//end try

    }//end addCart()


}//end class
