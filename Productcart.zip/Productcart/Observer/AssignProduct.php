<?php

namespace Ey\Productcart\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class AssignProduct implements ObserverInterface {
    protected $_checkoutSession;
    protected $formKey;
    protected $cart;
    protected $productFactory;

    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Model\ProductFactory $productFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->productFactory = $productFactory;
    }

    public function execute(Observer $observer) {

        $writer = new \Zend_Log_Writer_Stream(BP.'/var/log/Observer.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('Start');

        /*$product = $observer->getProduct();
        $logger->info($product->getIsAssignproduct());
        if($product->getIsAssignproduct()){
            $assignProducts      = $product->getAssignProducts();
            $assignProductsArray = explode(',', $assignProducts);
            foreach ($assignProductsArray as $assignProductId) {
                $free_product = $this->productFactory->create()->load($assignProductId);
                $params = [
                            'form_key' => $this->formKey->getFormKey(),
                            'product_id' => $free_product->getId(), //product Id
                            'qty' => 1, //quantity of product
                        ];

                $this->cart->addProduct($free_product, $params);
                $productItem = $this->getProductQuote($free_product);

                $this->cart->save();
            }
        }*/

        /*$quoteItems = $this->_checkoutSession->getQuote()->getAllVisibleItems();
        foreach ($quoteItems as $item) {
            $productId = $item->getProductId();
            $free_product = $this->productFactory->create()->load(117);
            $params = [
                'form_key' => $this->formKey->getFormKey(),
                'product_id' => $free_product->getId(), //product Id
                'qty' => 1, //quantity of product
            ];

            $this->cart->addProduct($free_product, $params);
            $productItem = $this->getProductQuote($free_product);
            //$productItem->setCustomPrice(153); //Set Custom Price
            //$productItem->setOriginalCustomPrice(153); //Set Custom Price
            $productItem->getProduct()->setIsSuperMode(true); //Enable super mode on the product.

        }
        $this->cart->save();*/
    }

    public function getProductQuote($product) {
        $quote = $this->_checkoutSession->getQuote();
        $cartItems = $quote->getItemByProduct($product);
        return $cartItems;
    }
}
