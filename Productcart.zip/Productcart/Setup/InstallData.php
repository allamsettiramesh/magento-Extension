<?php

namespace Ey\Productcart\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
       private $eavSetupFactory;

       public function __construct(EavSetupFactory $eavSetupFactory){
        $this->eavSetupFactory = $eavSetupFactory;
       }

       public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {
        $setup->startSetup();
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'assign_products');
        $eavSetup->addAttribute(\Magento\Catalog\Model\Product::ENTITY, 'assign_products',
          [
            'group' => 'Assign Products',
            'label' => 'Assign Products',
            'type' => 'text',
            'input' => 'multiselect',
            'source' => 'Ey\Productcart\Model\Config\Product\AssignProducts',
            'required' => false,
            'sort_order' => 30,
            'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_STORE,
            'used_in_product_listing' => true,
            'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
            'visible_on_front' => false
          ]
        );

           $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'is_assignproduct');
           $eavSetup->addAttribute(\Magento\Catalog\Model\Product::ENTITY, 'is_assignproduct', [
               'group' => 'Assign Products',
               'type' => 'int',
               'sort_order' => 20,
               'backend' => '',
               'frontend' => '',
               'label' => 'Is Assign Product',
               'input' => 'boolean',
               'class' => '',
               'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
               'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
               'visible' => true,
               'required' => false,
               'user_defined' => false,
               'default' => '',
               'searchable' => false,
               'filterable' => false,
               'comparable' => false,
               'visible_on_front' => false,
               'used_in_product_listing' => true,
               'unique' => false,
               'apply_to' => ''
           ]);
        $setup->endSetup();
      }

}
