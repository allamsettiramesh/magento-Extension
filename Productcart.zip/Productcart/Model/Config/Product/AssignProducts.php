<?php

   namespace Ey\Productcart\Model\Config\Product;

   use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

   class AssignProducts extends AbstractSource{

       protected $optionFactory;

       protected $_productCollectionFactory;

       public function __construct(\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
       )
       {
           $this->_productCollectionFactory = $productCollectionFactory;
       }

	    public function getAllOptions()
	    {
            $ids = [4];
            $this->_options = [];
            $collection = $this->_productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->addCategoriesFilter(['in' => $ids]);
            foreach ($collection as $product) {
                $this->_options[] = ['label' => $product->getName(), 'value' => $product->getId()];
            }
	       return $this->_options;
	   }

   }
