<?php

 namespace Ey\Productcart\Model;

 use Magento\Catalog\Api\ProductRepositoryInterface;
 use Magento\Catalog\Model\Product;
 use Magento\Checkout\Model\Cart\CartInterface;
 use Magento\Checkout\Model\Session;
 use Magento\Framework\DataObject;
 use Magento\Framework\Exception\NoSuchEntityException;

 class Cart extends \Magento\Checkout\Model\Cart{

     /**
      * Shopping cart items summary quantity(s)
      *
      * @var int|null
      */
     protected $_summaryQty;

     /**
      * List of product ids in shopping cart
      *
      * @var int[]|null
      */
     protected $_productIds;

     /**
      * Core event manager proxy
      *
      * @var \Magento\Framework\Event\ManagerInterface
      */
     protected $_eventManager;

     /**
      * Core store config
      *
      * @var \Magento\Framework\App\Config\ScopeConfigInterface
      */
     protected $_scopeConfig;

     /**
      * @var \Magento\Store\Model\StoreManagerInterface
      */
     protected $_storeManager;

     /**
      * @var \Magento\Checkout\Model\ResourceModel\Cart
      */
     protected $_resourceCart;

     /**
      * @var Session
      */
     protected $_checkoutSession;

     /**
      * @var \Magento\Customer\Model\Session
      */
     protected $_customerSession;

     /**
      * @var \Magento\Framework\Message\ManagerInterface
      */
     protected $messageManager;

     /**
      * @var \Magento\CatalogInventory\Api\StockRegistryInterface
      */
     protected $stockRegistry;

     /**
      * @var \Magento\CatalogInventory\Api\StockStateInterface
      */
     protected $stockState;

     /**
      * @var \Magento\Quote\Api\CartRepositoryInterface
      */
     protected $quoteRepository;

     /**
      * @var ProductRepositoryInterface
      */
     protected $productRepository;

     /**
      * @var \Magento\Checkout\Model\Cart\RequestInfoFilterInterface
      */
     private $requestInfoFilter;

     /**
      * @param \Magento\Framework\Event\ManagerInterface $eventManager
      * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
      * @param \Magento\Store\Model\StoreManagerInterface $storeManager
      * @param \Magento\Checkout\Model\ResourceModel\Cart $resourceCart
      * @param Session $checkoutSession
      * @param \Magento\Customer\Model\Session $customerSession
      * @param \Magento\Framework\Message\ManagerInterface $messageManager
      * @param \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
      * @param \Magento\CatalogInventory\Api\StockStateInterface $stockState
      * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
      * @param ProductRepositoryInterface $productRepository
      * @param array $data
      * @codeCoverageIgnore
      * @SuppressWarnings(PHPMD.ExcessiveParameterList)
      */
     public function __construct(
         \Magento\Framework\Event\ManagerInterface $eventManager,
         \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
         \Magento\Store\Model\StoreManagerInterface $storeManager,
         \Magento\Checkout\Model\ResourceModel\Cart $resourceCart,
         Session $checkoutSession,
         \Magento\Customer\Model\Session $customerSession,
         \Magento\Framework\Message\ManagerInterface $messageManager,
         \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
         \Magento\CatalogInventory\Api\StockStateInterface $stockState,
         \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
         ProductRepositoryInterface $productRepository,
         array $data = []
     ) {
         $this->_eventManager = $eventManager;
         $this->_scopeConfig = $scopeConfig;
         $this->_storeManager = $storeManager;
         $this->_resourceCart = $resourceCart;
         $this->_checkoutSession = $checkoutSession;
         $this->_customerSession = $customerSession;
         $this->messageManager = $messageManager;
         $this->stockRegistry = $stockRegistry;
         $this->stockState = $stockState;
         $this->quoteRepository = $quoteRepository;
         parent::__construct($data);
         $this->productRepository = $productRepository;
     }

     public function test(){
         echo "hello";
     }


 }
