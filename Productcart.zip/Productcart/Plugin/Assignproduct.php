<?php

  namespace Ey\Productcart\Plugin;

  class Assignproduct{

      protected $checkoutSession;

      public function __construct(\Magento\Checkout\Model\Session $checkoutSession){

      }
      public function beforeAddProduct($subject, $productInfo, $requestInfo = null){
          $writer = new \Zend_Log_Writer_Stream(BP.'/var/log/plugin.log');
          $logger = new \Zend_Log();
          $logger->addWriter($writer);
          $logger->info('Start');
          $logger->info(json_encode($productInfo->getData()));

      }

      public function afterAddProduct(){

      }
  }
