<?php
namespace Ey\Productcart\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\Product;

class CheckoutCartProductAddAfter implements ObserverInterface
{
    protected $formKey;

    protected $cart;

    protected $product;

    public function __construct(FormKey $formKey,
                                Cart $cart,
                                Product $product)
    {
         $this->product = $product;
         $this->cart = $cart;
         $this->formKey = $formKey;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $product = $observer->getEvent()->getData('product');
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/observer2.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        if($product->getIsAssignproduct() == 1 && $product->getAssignsProducts() != '') {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $formkey = $objectManager->create('\Magento\Framework\Data\Form\FormKey');
            $assignProductsString = $product->getAssignsProducts();
            $assignProductsArray = explode(',',$product->getAssignsProducts());
            foreach($assignProductsArray as $assignProductItem){
                $productObj = $objectManager->create('\Magento\Catalog\Model\Product');
                $cartObj = $objectManager->create('\Magento\Checkout\Model\Cart');
                $productDetails = explode("=",$assignProductItem);
                $productId = $productObj->getIdBySku($productDetails[0]);
                $qty = $productDetails[1];
                if($productDetails[0] != '' && $productDetails[1] != '') {
                    //x$formKeyValue = $this->formkey->getFormKey();
                    $params = array(
                                    'form_key' => $formkey->getFormKey(),
                                    'product' => $productId,
                                    'qty' => $qty
                                );
                    $product = $productObj->load($productId);
                    $cartObj->addProduct($product, $params);
                }
            }
            $cartObj->save();
        }
    }
}
